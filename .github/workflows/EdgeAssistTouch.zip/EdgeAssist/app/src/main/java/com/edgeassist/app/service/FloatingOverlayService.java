package com.edgeassist.app.service;

import android.animation.ValueAnimator;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.edgeassist.app.R;
import com.edgeassist.app.SettingsActivity;
import com.edgeassist.app.actions.ActionResult;
import com.edgeassist.app.actions.ShortcutActions;
import com.edgeassist.app.overlay.ShortcutItem;
import com.edgeassist.app.overlay.SwipePanelView;
import com.edgeassist.app.theme.ThemeManager;
import com.edgeassist.app.util.Prefs;

/**
 * Service untuk floating assistive button (mirip AssistiveTouch iPhone) + panel shortcut.
 *
 * PERFORMANCE:
 * - Tidak ada Handler/Timer loop terus-menerus. Handler hanya dipakai untuk SATU
 *   postDelayed auto-hide, yang dibatalkan/direset saat disentuh - bukan polling berkala.
 * - Saat idle, hanya 1 View kecil (floating button) yang aktif di WindowManager.
 * - Panel shortcut baru dibuat & ditambahkan ke WindowManager saat dibuka, dan
 *   langsung dihapus (removeView) saat ditutup - tidak pernah dua-duanya idle bersamaan.
 */
public class FloatingOverlayService extends Service {

    private static final int DRAG_THRESHOLD_PX_DP = 6;

    private WindowManager windowManager;
    private Prefs prefs;
    private ThemeManager themeManager;
    private ShortcutActions shortcutActions;
    private final Handler handler = new Handler();

    // Floating button
    private FrameLayout buttonContainer;
    private View buttonCircle;
    private WindowManager.LayoutParams buttonParams;
    private boolean isDraggingButton = false;
    private float touchStartRawX, touchStartRawY;
    private int paramsStartX, paramsStartY;

    // Panel
    private SwipePanelView panelView;
    private WindowManager.LayoutParams panelParams;
    private boolean panelOpen = false;

    // Full-screen transparan, hanya ada SELAMA panel terbuka, untuk mendeteksi
    // "tap di luar panel -> tutup panel" (spesifikasi bagian 11). Dihapus lagi
    // begitu panel ditutup, jadi tidak membebani saat idle.
    private FrameLayout outsideCatcher;
    private WindowManager.LayoutParams catcherParams;

    private final Runnable autoHideRunnable = this::applyAutoHideAlpha;

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        prefs = new Prefs(this);
        themeManager = new ThemeManager(prefs);
        shortcutActions = new ShortcutActions(this);
        createFloatingButton();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    // ------------------------------------------------------------------
    // FLOATING BUTTON
    // ------------------------------------------------------------------

    private void createFloatingButton() {
        buttonContainer = new FrameLayout(this);

        int sizeDp = 36 + (int) ((prefs.getButtonSize() / 100f) * 28); // 36dp - 64dp
        int sizePx = dp(sizeDp);

        buttonCircle = new View(this);
        GradientDrawable bg = (GradientDrawable) getResources().getDrawable(R.drawable.circle_button_bg).mutate();
        themeManager.applyToButtonBackground(bg, prefs.getButtonOpacity());
        buttonCircle.setBackground(bg);
        FrameLayout.LayoutParams innerParams = new FrameLayout.LayoutParams(sizePx, sizePx);
        buttonContainer.addView(buttonCircle, innerParams);
        buttonContainer.setElevation(dp(4));

        int type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;

        buttonParams = new WindowManager.LayoutParams(
                sizePx, sizePx, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int defaultY = dm.heightPixels / 2;
        int side = prefs.getSide(); // 0 = left, 1 = right
        buttonParams.gravity = Gravity.TOP | (side == 0 ? Gravity.LEFT : Gravity.RIGHT);
        buttonParams.x = prefs.getButtonX(0);
        buttonParams.y = prefs.getButtonY(defaultY);

        buttonContainer.setOnTouchListener(this::onButtonTouch);

        windowManager.addView(buttonContainer, buttonParams);
        scheduleAutoHide();
    }

    private boolean onButtonTouch(View v, MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                touchStartRawX = event.getRawX();
                touchStartRawY = event.getRawY();
                paramsStartX = buttonParams.x;
                paramsStartY = buttonParams.y;
                isDraggingButton = false;
                cancelAutoHide();
                return true;

            case MotionEvent.ACTION_MOVE: {
                float dx = event.getRawX() - touchStartRawX;
                float dy = event.getRawY() - touchStartRawY;
                if (!isDraggingButton && (Math.abs(dx) > dp(DRAG_THRESHOLD_PX_DP) || Math.abs(dy) > dp(DRAG_THRESHOLD_PX_DP))) {
                    isDraggingButton = true;
                }
                if (isDraggingButton) {
                    boolean isRightGravity = (buttonParams.gravity & Gravity.RIGHT) == Gravity.RIGHT;
                    buttonParams.x = paramsStartX + (int) (isRightGravity ? -dx : dx);
                    buttonParams.y = paramsStartY + (int) dy;
                    windowManager.updateViewLayout(buttonContainer, buttonParams);
                }
                return true;
            }

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (isDraggingButton) {
                    snapButtonToNearestEdge();
                } else {
                    togglePanel();
                }
                scheduleAutoHide();
                return true;
        }
        return false;
    }

    /** Setelah drag selesai, tombol nempel ke tepi kiri/kanan terdekat (perilaku khas AssistiveTouch). */
    private void snapButtonToNearestEdge() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int screenWidth = dm.widthPixels;
        int buttonWidth = buttonParams.width;

        boolean wasRightGravity = (buttonParams.gravity & Gravity.RIGHT) == Gravity.RIGHT;
        int absoluteX = wasRightGravity ? (screenWidth - buttonWidth - buttonParams.x) : buttonParams.x;
        int centerX = absoluteX + buttonWidth / 2;

        boolean snapRight = centerX > screenWidth / 2;
        buttonParams.gravity = Gravity.TOP | (snapRight ? Gravity.RIGHT : Gravity.LEFT);
        buttonParams.x = 0;

        // clamp Y agar tidak keluar layar
        int screenHeight = dm.heightPixels;
        if (buttonParams.y < 0) buttonParams.y = 0;
        if (buttonParams.y > screenHeight - buttonParams.height) buttonParams.y = screenHeight - buttonParams.height;

        windowManager.updateViewLayout(buttonContainer, buttonParams);
        prefs.setSide(snapRight ? 1 : 0);
        prefs.setButtonPosition(buttonParams.x, buttonParams.y);
    }

    // ------------------------------------------------------------------
    // PANEL
    // ------------------------------------------------------------------

    private void togglePanel() {
        if (panelOpen) {
            closePanel();
        } else {
            openPanel();
        }
    }

    private void openPanel() {
        if (panelOpen) return;
        ShortcutItem[][] pages = ShortcutItem.buildPages(this);

        panelView = new SwipePanelView(this, pages, themeManager, prefs.getPanelOpacity(), prefs.getIconSize());
        panelView.setAnimationEnabled(prefs.isAnimationEnabled());
        panelView.setOnShortcutClickListener(this::handleShortcutClick);

        int type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        panelParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);

        boolean isRight = (buttonParams.gravity & Gravity.RIGHT) == Gravity.RIGHT;
        panelParams.gravity = Gravity.TOP | (isRight ? Gravity.RIGHT : Gravity.LEFT);
        panelParams.x = isRight ? dp(8) : dp(8);
        int yPos = buttonParams.y;
        panelParams.y = yPos;

        addOutsideCatcher();
        windowManager.addView(panelView, panelParams);
        panelOpen = true;
        cancelAutoHide();
        buttonContainer.setAlpha(1f);
    }

    private void closePanel() {
        if (!panelOpen || panelView == null) return;
        try {
            windowManager.removeView(panelView);
        } catch (IllegalArgumentException ignored) {
        }
        removeOutsideCatcher();
        panelView = null;
        panelOpen = false;
        scheduleAutoHide();
    }

    /** Ditambahkan DI BAWAH panel & tombol, transparan, hanya untuk menutup panel saat tap di luar. */
    private void addOutsideCatcher() {
        outsideCatcher = new FrameLayout(this);
        outsideCatcher.setOnTouchListener((v, event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                closePanel();
            }
            return true;
        });
        int type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        catcherParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        catcherParams.gravity = Gravity.TOP | Gravity.LEFT;
        windowManager.addView(outsideCatcher, catcherParams);
    }

    private void removeOutsideCatcher() {
        if (outsideCatcher != null) {
            try {
                windowManager.removeView(outsideCatcher);
            } catch (IllegalArgumentException ignored) {
            }
            outsideCatcher = null;
        }
    }

    private void handleShortcutClick(ShortcutItem item) {
        switch (item.id) {
            case BACK:
                execute(shortcutActions.back());
                closePanel();
                break;
            case HOME:
                execute(shortcutActions.home());
                closePanel();
                break;
            case RECENTS:
                execute(shortcutActions.recents());
                closePanel();
                break;
            case VOL_UP:
                execute(shortcutActions.volumeUp());
                break; // volume tetap buka panel agar user bisa tap berkali-kali
            case VOL_DOWN:
                execute(shortcutActions.volumeDown());
                break;
            case MUTE:
                execute(shortcutActions.toggleMute());
                closePanel();
                break;
            case LOCK:
                execute(shortcutActions.lockScreen());
                closePanel();
                break;
            case POWER:
                execute(shortcutActions.powerMenu());
                closePanel();
                break;
            case SCREENSHOT:
                execute(shortcutActions.screenshot());
                break;
            case NOTIFICATIONS:
                execute(shortcutActions.notifications());
                closePanel();
                break;
            case QUICK_SETTINGS:
                execute(shortcutActions.quickSettings());
                closePanel();
                break;
            case WIFI:
                execute(shortcutActions.toggleWifi());
                closePanel();
                break;
            case FLASHLIGHT:
                execute(shortcutActions.toggleFlashlight());
                break;
            case MORE:
                Toast.makeText(this, "Menu tambahan segera hadir.", Toast.LENGTH_SHORT).show();
                break;
            case SETTINGS:
                Intent settingsIntent = new Intent(this, SettingsActivity.class);
                settingsIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(settingsIntent);
                closePanel();
                break;
        }
    }

    private void execute(ActionResult result) {
        if (!result.success && result.message != null) {
            Toast.makeText(this, result.message, Toast.LENGTH_SHORT).show();
        }
    }

    // ------------------------------------------------------------------
    // AUTO HIDE (satu-shot postDelayed, BUKAN polling berkala)
    // ------------------------------------------------------------------

    private void scheduleAutoHide() {
        cancelAutoHide();
        if (prefs.isAutoHideEnabled() && !panelOpen) {
            handler.postDelayed(autoHideRunnable, prefs.getAutoHideDelaySeconds() * 1000L);
        }
    }

    private void cancelAutoHide() {
        handler.removeCallbacks(autoHideRunnable);
    }

    private void applyAutoHideAlpha() {
        if (buttonContainer != null && !panelOpen) {
            ValueAnimator anim = ValueAnimator.ofFloat(buttonContainer.getAlpha(), 0.35f);
            anim.setDuration(250);
            anim.addUpdateListener(a -> buttonContainer.setAlpha((float) a.getAnimatedValue()));
            anim.start();
        }
    }

    // ------------------------------------------------------------------

    @Override
    public void onDestroy() {
        super.onDestroy();
        cancelAutoHide();
        shortcutActions.releaseResources();
        try {
            if (buttonContainer != null) windowManager.removeView(buttonContainer);
        } catch (IllegalArgumentException ignored) {
        }
        try {
            if (panelView != null) windowManager.removeView(panelView);
        } catch (IllegalArgumentException ignored) {
        }
        removeOutsideCatcher();
    }

    private int dp(int value) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics());
    }
}
