package com.edgeassist.app.actions;

import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.util.Log;

/**
 * Kontrol flashlight memakai CameraManager.setTorchMode() (API 23+).
 * PENTING: metode ini TIDAK membutuhkan permission CAMERA di Android untuk
 * kebanyakan device, karena tidak membuka sesi kamera - hanya toggle torch
 * pada unit LED yang terpasang di kamera belakang.
 * Jika device tidak punya flash unit, ditangani dengan graceful fallback.
 */
public class FlashlightController {

    private static final String TAG = "FlashlightController";

    private final CameraManager cameraManager;
    private String cameraId;
    private boolean isOn = false;
    private boolean available = false;

    public FlashlightController(Context context) {
        cameraManager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
        available = context.getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH);
        if (available && cameraManager != null) {
            try {
                for (String id : cameraManager.getCameraIdList()) {
                    Boolean hasFlash = cameraManager.getCameraCharacteristics(id)
                            .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE);
                    if (hasFlash != null && hasFlash) {
                        cameraId = id;
                        break;
                    }
                }
                if (cameraId == null) available = false;
            } catch (CameraAccessException e) {
                Log.w(TAG, "Tidak dapat mengakses daftar kamera: " + e.getMessage());
                available = false;
            }
        }
    }

    public boolean isAvailable() {
        return available;
    }

    /** @return true jika berhasil toggle, false jika tidak tersedia/gagal (fallback graceful). */
    public boolean toggle() {
        if (!available || cameraManager == null || cameraId == null) {
            return false;
        }
        try {
            isOn = !isOn;
            cameraManager.setTorchMode(cameraId, isOn);
            return true;
        } catch (CameraAccessException e) {
            Log.w(TAG, "Gagal toggle flashlight: " + e.getMessage());
            isOn = !isOn; // revert state
            return false;
        }
    }

    public void release() {
        // setTorchMode tidak butuh sesi kamera terbuka, jadi tidak ada resource
        // eksplisit yang perlu dilepas. Pastikan torch dimatikan saat service berhenti.
        if (available && isOn && cameraManager != null && cameraId != null) {
            try {
                cameraManager.setTorchMode(cameraId, false);
            } catch (CameraAccessException ignored) {
            }
            isOn = false;
        }
    }
}
