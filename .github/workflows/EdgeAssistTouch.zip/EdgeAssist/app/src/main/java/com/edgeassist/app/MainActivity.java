package com.edgeassist.app;

import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.edgeassist.app.service.EdgeAccessibilityService;
import com.edgeassist.app.service.FloatingOverlayService;
import com.edgeassist.app.util.Prefs;

/**
 * Setup wizard 4 langkah: Welcome -> Accessibility -> Overlay -> Finish.
 * TIDAK meminta semua permission sekaligus (sesuai spesifikasi bagian 17).
 */
public class MainActivity extends AppCompatActivity {

    private static final int STEP_WELCOME = 0;
    private static final int STEP_ACCESSIBILITY = 1;
    private static final int STEP_OVERLAY = 2;
    private static final int STEP_FINISH = 3;

    private int currentStep = STEP_WELCOME;
    private Prefs prefs;

    private TextView tvTitle, tvDesc, tvStatus;
    private Button btnAction, btnNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prefs = new Prefs(this);

        tvTitle = findViewById(R.id.tvStepTitle);
        tvDesc = findViewById(R.id.tvStepDesc);
        tvStatus = findViewById(R.id.tvStepStatus);
        btnAction = findViewById(R.id.btnAction);
        btnNext = findViewById(R.id.btnNext);

        if (prefs.isFirstRunDone() && isAccessibilityEnabled() && Settings.canDrawOverlays(this)) {
            // Sudah pernah setup dan semua izin masih aktif -> langsung ke Settings, tidak perlu wizard lagi.
            startActivity(new Intent(this, SettingsActivity.class));
            finish();
            return;
        }

        renderStep();
    }

    @Override
    protected void onResume() {
        super.onResume();
        renderStep(); // refresh status setiap kali kembali dari halaman Settings sistem
    }

    private void renderStep() {
        switch (currentStep) {
            case STEP_WELCOME:
                tvTitle.setText(R.string.setup_welcome_title);
                tvDesc.setText(R.string.setup_welcome_desc);
                tvStatus.setVisibility(View.GONE);
                btnAction.setVisibility(View.GONE);
                btnNext.setText(R.string.btn_next);
                btnNext.setOnClickListener(v -> goToStep(STEP_ACCESSIBILITY));
                break;

            case STEP_ACCESSIBILITY:
                tvTitle.setText(R.string.setup_accessibility_title);
                tvDesc.setText(R.string.setup_accessibility_desc);
                boolean accEnabled = isAccessibilityEnabled();
                tvStatus.setVisibility(View.VISIBLE);
                tvStatus.setText(accEnabled ? R.string.status_granted : R.string.status_not_granted);
                btnAction.setVisibility(View.VISIBLE);
                btnAction.setText(R.string.btn_open_accessibility_settings);
                btnAction.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
                btnNext.setText(R.string.btn_next);
                btnNext.setOnClickListener(v -> goToStep(STEP_OVERLAY));
                break;

            case STEP_OVERLAY:
                tvTitle.setText(R.string.setup_overlay_title);
                tvDesc.setText(R.string.setup_overlay_desc);
                boolean overlayGranted = Settings.canDrawOverlays(this);
                tvStatus.setVisibility(View.VISIBLE);
                tvStatus.setText(overlayGranted ? R.string.status_granted : R.string.status_not_granted);
                btnAction.setVisibility(View.VISIBLE);
                btnAction.setText(R.string.btn_open_overlay_settings);
                btnAction.setOnClickListener(v -> {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                });
                btnNext.setText(R.string.btn_next);
                btnNext.setOnClickListener(v -> goToStep(STEP_FINISH));
                break;

            case STEP_FINISH:
                tvTitle.setText(R.string.setup_finish_title);
                tvDesc.setText(R.string.setup_finish_desc);
                tvStatus.setVisibility(View.GONE);
                btnAction.setVisibility(View.GONE);
                btnNext.setText(R.string.btn_finish);
                btnNext.setOnClickListener(v -> finishSetup());
                break;
        }
    }

    private void goToStep(int step) {
        currentStep = step;
        renderStep();
    }

    private void finishSetup() {
        prefs.setFirstRunDone(true);
        if (Settings.canDrawOverlays(this) && isAccessibilityEnabled()) {
            startService(new Intent(this, FloatingOverlayService.class));
        }
        startActivity(new Intent(this, SettingsActivity.class));
        finish();
    }

    private boolean isAccessibilityEnabled() {
        String enabledServices = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(enabledServices)) return false;
        ComponentName target = new ComponentName(this, EdgeAccessibilityService.class);
        return enabledServices.contains(target.flattenToString());
    }
}
