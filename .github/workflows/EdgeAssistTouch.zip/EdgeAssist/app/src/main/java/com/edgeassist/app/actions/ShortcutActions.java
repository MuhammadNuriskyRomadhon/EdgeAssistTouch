package com.edgeassist.app.actions;

import android.accessibilityservice.AccessibilityService;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.provider.Settings;

import com.edgeassist.app.admin.EdgeDeviceAdminReceiver;
import com.edgeassist.app.service.EdgeAccessibilityService;
import com.edgeassist.app.service.ServiceHolder;

/**
 * Implementasi eksekusi setiap shortcut.
 * Setiap method mengembalikan ActionResult agar pemanggil (panel UI) bisa
 * menampilkan pesan graceful, bukan crash, ketika sebuah fitur tidak tersedia.
 *
 * Tidak ada root, tidak ada hidden API, tidak ada reflection ke API privat.
 */
public class ShortcutActions {

    private final Context appContext;
    private final FlashlightController flashlightController;

    public ShortcutActions(Context context) {
        this.appContext = context.getApplicationContext();
        this.flashlightController = new FlashlightController(appContext);
    }

    private ActionResult runGlobal(int globalAction) {
        EdgeAccessibilityService service = ServiceHolder.getService();
        if (service == null) {
            return ActionResult.fail("Silakan aktifkan EdgeAssist Accessibility Service.");
        }
        boolean ok = service.runGlobalAction(globalAction);
        return ok ? ActionResult.ok() : ActionResult.fail("Aksi gagal dijalankan oleh sistem.");
    }

    public ActionResult back() {
        return runGlobal(AccessibilityService.GLOBAL_ACTION_BACK);
    }

    public ActionResult home() {
        return runGlobal(AccessibilityService.GLOBAL_ACTION_HOME);
    }

    public ActionResult recents() {
        return runGlobal(AccessibilityService.GLOBAL_ACTION_RECENTS);
    }

    public ActionResult notifications() {
        return runGlobal(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS);
    }

    public ActionResult quickSettings() {
        return runGlobal(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS);
    }

    public ActionResult powerMenu() {
        return runGlobal(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG);
    }

    public ActionResult volumeUp() {
        AudioManager am = (AudioManager) appContext.getSystemService(Context.AUDIO_SERVICE);
        if (am == null) return ActionResult.fail("Audio service tidak tersedia.");
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI);
        return ActionResult.ok();
    }

    public ActionResult volumeDown() {
        AudioManager am = (AudioManager) appContext.getSystemService(Context.AUDIO_SERVICE);
        if (am == null) return ActionResult.fail("Audio service tidak tersedia.");
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI);
        return ActionResult.ok();
    }

    public ActionResult toggleMute() {
        AudioManager am = (AudioManager) appContext.getSystemService(Context.AUDIO_SERVICE);
        if (am == null) return ActionResult.fail("Audio service tidak tersedia.");
        // ADJUST_TOGGLE_MUTE tersedia sejak API 23, aman untuk target API 27.
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, AudioManager.FLAG_SHOW_UI);
        return ActionResult.ok();
    }

    /**
     * Lock Screen di API 27: GLOBAL_ACTION_LOCK_SCREEN baru ada di API 28+,
     * jadi kita pakai DevicePolicyManager.lockNow() yang butuh Device Admin aktif.
     */
    public ActionResult lockScreen() {
        DevicePolicyManager dpm = (DevicePolicyManager) appContext.getSystemService(Context.DEVICE_POLICY_SERVICE);
        ComponentName admin = new ComponentName(appContext, EdgeDeviceAdminReceiver.class);
        if (dpm == null || !dpm.isAdminActive(admin)) {
            return ActionResult.fail("Aktifkan Device Admin agar Lock Screen bisa berfungsi di Android 8.1.");
        }
        try {
            dpm.lockNow();
            return ActionResult.ok();
        } catch (SecurityException e) {
            return ActionResult.fail("Sistem menolak permintaan lock screen.");
        }
    }

    /** Intent untuk membuka layar permintaan aktivasi Device Admin (dipanggil dari UI, bukan di sini). */
    public static Intent createDeviceAdminRequestIntent(Context context) {
        ComponentName admin = new ComponentName(context, EdgeDeviceAdminReceiver.class);
        Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin);
        intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Diperlukan agar EdgeAssist bisa mengunci layar di Android 8.1.");
        return intent;
    }

    /**
     * Screenshot: TIDAK ADA global action resmi di API 27 (GLOBAL_ACTION_TAKE_SCREENSHOT
     * baru ada di API 28). Kita tidak berpura-pura fitur ini bekerja.
     */
    public ActionResult screenshot() {
        return ActionResult.fail("Screenshot tidak tersedia secara native pada Android 8.1 (API 27) tanpa root.");
    }

    public ActionResult toggleFlashlight() {
        if (!flashlightController.isAvailable()) {
            return ActionResult.fail("Flashlight tidak tersedia pada perangkat ini.");
        }
        boolean ok = flashlightController.toggle();
        return ok ? ActionResult.ok() : ActionResult.fail("Gagal mengaktifkan flashlight.");
    }

    /**
     * Toggle Wi-Fi. WifiManager.setWifiEnabled() masih berfungsi untuk app dengan
     * targetSdkVersion 27 (sebelum pembatasan Android 10+). Jika gagal (mis. dibatasi
     * OEM/XOS), fallback membuka halaman Settings Wi-Fi.
     */
    public ActionResult toggleWifi() {
        WifiManager wm = (WifiManager) appContext.getSystemService(Context.WIFI_SERVICE);
        if (wm != null) {
            try {
                boolean current = wm.isWifiEnabled();
                boolean changed = wm.setWifiEnabled(!current);
                if (changed) return ActionResult.ok();
            } catch (SecurityException ignored) {
                // lanjut ke fallback
            }
        }
        // Fallback resmi: buka halaman pengaturan Wi-Fi.
        Intent intent = new Intent(Settings.ACTION_WIFI_SETTINGS);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        appContext.startActivity(intent);
        return ActionResult.fail("Membuka pengaturan Wi-Fi (toggle langsung tidak diizinkan sistem).");
    }

    public void releaseResources() {
        flashlightController.release();
    }
}
