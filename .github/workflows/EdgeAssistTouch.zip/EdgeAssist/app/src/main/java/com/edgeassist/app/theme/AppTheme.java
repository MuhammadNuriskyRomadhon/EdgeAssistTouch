package com.edgeassist.app.theme;

/**
 * 8 tema bawaan sesuai spesifikasi: Dark, Light, Midnight, Ocean, Purple, Red, Green, Minimal.
 * Warna disimpan sebagai literal ARGB agar tidak bergantung resource context saat
 * dipakai di dalam Service (overlay window tidak selalu punya akses mudah ke tema activity).
 */
public enum AppTheme {
    DARK(0xFF1C1C1E, 0xFF0A84FF, 0xFFFFFFFF),
    LIGHT(0xFFF5F5F5, 0xFF1976D2, 0xFF1C1C1E),
    MIDNIGHT(0xFF0D1117, 0xFF58A6FF, 0xFFC9D1D9),
    OCEAN(0xFF04293A, 0xFF00B4D8, 0xFFCAF0F8),
    PURPLE(0xFF251140, 0xFFB388FF, 0xFFEDE7F6),
    RED(0xFF2B0A0A, 0xFFFF5252, 0xFFFFEBEE),
    GREEN(0xFF0B2A1D, 0xFF4CD964, 0xFFE8F5E9),
    MINIMAL(0xFFFFFFFF, 0xFF424242, 0xFF212121);

    public final int backgroundColor;
    public final int accentColor;
    public final int textColor;

    AppTheme(int backgroundColor, int accentColor, int textColor) {
        this.backgroundColor = backgroundColor;
        this.accentColor = accentColor;
        this.textColor = textColor;
    }

    public static AppTheme fromIndex(int index) {
        AppTheme[] values = values();
        if (index < 0 || index >= values.length) return DARK;
        return values[index];
    }
}
