package com.edgeassist.app;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.edgeassist.app.actions.ShortcutActions;
import com.edgeassist.app.admin.EdgeDeviceAdminReceiver;
import com.edgeassist.app.service.FloatingOverlayService;
import com.edgeassist.app.util.Prefs;

public class SettingsActivity extends AppCompatActivity {

    private Prefs prefs;

    private Spinner spinnerTheme;
    private RadioGroup radioSide;
    private SeekBar seekButtonSize, seekButtonOpacity, seekPanelOpacity, seekIconSize, seekAutoHideDelay;
    private Switch switchAutoHide, switchAnimation;
    private Button btnPrivacy, btnReset;

    private boolean isLoadingUi = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        prefs = new Prefs(this);

        bindViews();
        loadCurrentValues();
        attachListeners();
        maybePromptDeviceAdmin();
    }

    private void bindViews() {
        spinnerTheme = findViewById(R.id.spinnerTheme);
        radioSide = findViewById(R.id.radioSide);
        seekButtonSize = findViewById(R.id.seekButtonSize);
        seekButtonOpacity = findViewById(R.id.seekButtonOpacity);
        seekPanelOpacity = findViewById(R.id.seekPanelOpacity);
        seekIconSize = findViewById(R.id.seekIconSize);
        seekAutoHideDelay = findViewById(R.id.seekAutoHideDelay);
        switchAutoHide = findViewById(R.id.switchAutoHide);
        switchAnimation = findViewById(R.id.switchAnimation);
        btnPrivacy = findViewById(R.id.btnPrivacy);
        btnReset = findViewById(R.id.btnReset);
    }

    private void loadCurrentValues() {
        isLoadingUi = true;
        spinnerTheme.setSelection(prefs.getThemeIndex());
        ((android.widget.RadioButton) findViewById(prefs.getSide() == 0 ? R.id.radioLeft : R.id.radioRight)).setChecked(true);
        seekButtonSize.setProgress(prefs.getButtonSize());
        seekButtonOpacity.setProgress(prefs.getButtonOpacity());
        seekPanelOpacity.setProgress(prefs.getPanelOpacity());
        seekIconSize.setProgress(prefs.getIconSize());
        seekAutoHideDelay.setProgress(prefs.getAutoHideDelaySeconds());
        switchAutoHide.setChecked(prefs.isAutoHideEnabled());
        switchAnimation.setChecked(prefs.isAnimationEnabled());
        isLoadingUi = false;
    }

    private void attachListeners() {
        spinnerTheme.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, android.view.View view, int position, long id) {
                if (isLoadingUi) return;
                prefs.setThemeIndex(position);
                restartOverlayIfRunning();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        radioSide.setOnCheckedChangeListener((group, checkedId) -> {
            if (isLoadingUi) return;
            prefs.setSide(checkedId == R.id.radioLeft ? 0 : 1);
            restartOverlayIfRunning();
        });

        seekButtonSize.setOnSeekBarChangeListener(seekListener(v -> {
            prefs.setButtonSize(v);
            restartOverlayIfRunning();
        }));
        seekButtonOpacity.setOnSeekBarChangeListener(seekListener(v -> {
            prefs.setButtonOpacity(v);
            restartOverlayIfRunning();
        }));
        seekPanelOpacity.setOnSeekBarChangeListener(seekListener(v -> {
            prefs.setPanelOpacity(v);
        }));
        seekIconSize.setOnSeekBarChangeListener(seekListener(v -> {
            prefs.setIconSize(v);
        }));
        seekAutoHideDelay.setOnSeekBarChangeListener(seekListener(v -> {
            prefs.setAutoHideDelaySeconds(Math.max(1, v));
        }));

        switchAutoHide.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isLoadingUi) return;
            prefs.setAutoHideEnabled(isChecked);
        });
        switchAnimation.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isLoadingUi) return;
            prefs.setAnimationEnabled(isChecked);
        });

        btnPrivacy.setOnClickListener(v -> startActivity(new Intent(this, PrivacyActivity.class)));

        btnReset.setOnClickListener(v -> {
            prefs.resetAll();
            loadCurrentValues();
            restartOverlayIfRunning();
            Toast.makeText(this, "Pengaturan direset ke default.", Toast.LENGTH_SHORT).show();
        });
    }

    private interface OnValue {
        void apply(int value);
    }

    private SeekBar.OnSeekBarChangeListener seekListener(OnValue onValue) {
        return new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (isLoadingUi || !fromUser) return;
                onValue.apply(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        };
    }

    /** Restart overlay service agar perubahan tampilan langsung terlihat. */
    private void restartOverlayIfRunning() {
        stopService(new Intent(this, FloatingOverlayService.class));
        startService(new Intent(this, FloatingOverlayService.class));
    }

    /** Tawarkan aktivasi Device Admin sekali saja agar shortcut Lock Screen berfungsi. */
    private void maybePromptDeviceAdmin() {
        if (prefs.wasDeviceAdminPrompted()) return;
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
        ComponentName admin = new ComponentName(this, EdgeDeviceAdminReceiver.class);
        if (dpm != null && !dpm.isAdminActive(admin)) {
            prefs.setDeviceAdminPrompted(true);
            startActivity(ShortcutActions.createDeviceAdminRequestIntent(this));
        }
    }
}
