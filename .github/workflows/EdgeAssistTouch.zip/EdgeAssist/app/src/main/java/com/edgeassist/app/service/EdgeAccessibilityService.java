package com.edgeassist.app.service;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;

/**
 * AccessibilityService MINIMAL.
 *
 * Hanya dipakai untuk performGlobalAction(). Konfigurasi di
 * res/xml/accessibility_service_config.xml menonaktifkan canRetrieveWindowContent,
 * sehingga service ini secara teknis TIDAK BISA membaca isi layar aplikasi lain
 * meskipun mau - ini sengaja dibatasi untuk menjaga privasi.
 *
 * Saat service tersambung, kita otomatis start FloatingOverlayService (jika
 * overlay permission juga sudah diberikan), dan sebaliknya hentikan saat service mati.
 */
public class EdgeAccessibilityService extends AccessibilityService {

    private static final String TAG = "EdgeAccessibilityService";

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        Log.i(TAG, "EdgeAssist Accessibility Service tersambung.");
        ServiceHolder.setService(this);

        // Auto-start floating overlay jika overlay permission sudah ada.
        if (android.provider.Settings.canDrawOverlays(this)) {
            Intent overlayIntent = new Intent(this, FloatingOverlayService.class);
            startService(overlayIntent);
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Sengaja kosong: kita tidak memproses/menyimpan event apa pun.
        // Kita hanya butuh service ini aktif agar performGlobalAction() tersedia.
    }

    @Override
    public void onInterrupt() {
        // Tidak ada state yang perlu dibersihkan.
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.i(TAG, "EdgeAssist Accessibility Service dinonaktifkan.");
        ServiceHolder.clear();
        stopService(new Intent(this, FloatingOverlayService.class));
        return super.onUnbind(intent);
    }

    /** Wrapper aman untuk global action, dipanggil dari ShortcutActions. */
    public boolean runGlobalAction(int globalAction) {
        try {
            return performGlobalAction(globalAction);
        } catch (Exception e) {
            Log.w(TAG, "Global action gagal: " + e.getMessage());
            return false;
        }
    }
}
