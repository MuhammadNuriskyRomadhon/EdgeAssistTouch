package com.edgeassist.app.actions;

public class ActionResult {
    public final boolean success;
    public final String message; // null jika sukses tanpa pesan tambahan

    private ActionResult(boolean success, String message) {
        this.success = success;
        this.message = message;
    }

    public static ActionResult ok() {
        return new ActionResult(true, null);
    }

    public static ActionResult fail(String message) {
        return new ActionResult(false, message);
    }
}
