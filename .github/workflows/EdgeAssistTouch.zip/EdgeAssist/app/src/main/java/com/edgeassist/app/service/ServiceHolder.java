package com.edgeassist.app.service;

import java.lang.ref.WeakReference;

/**
 * Holder statis yang menyimpan referensi lemah (WeakReference) ke instance
 * EdgeAccessibilityService yang sedang berjalan, agar FloatingOverlayService
 * (service terpisah) bisa memanggil performGlobalAction() tanpa binding rumit.
 * WeakReference dipakai supaya tidak menyebabkan memory leak jika service mati.
 */
public class ServiceHolder {

    private static WeakReference<EdgeAccessibilityService> serviceRef;

    public static void setService(EdgeAccessibilityService service) {
        serviceRef = new WeakReference<>(service);
    }

    public static void clear() {
        serviceRef = null;
    }

    public static EdgeAccessibilityService getService() {
        return serviceRef != null ? serviceRef.get() : null;
    }

    public static boolean isServiceRunning() {
        return getService() != null;
    }
}
