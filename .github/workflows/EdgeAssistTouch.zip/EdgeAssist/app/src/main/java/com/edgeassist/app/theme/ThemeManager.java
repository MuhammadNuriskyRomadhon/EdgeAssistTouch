package com.edgeassist.app.theme;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.View;

import com.edgeassist.app.util.Prefs;

/**
 * Menerapkan warna tema aktif ke drawable secara programatik (tanpa perlu
 * banyak file drawable per tema -> hemat resource & APK size).
 */
public class ThemeManager {

    private final Prefs prefs;

    public ThemeManager(Prefs prefs) {
        this.prefs = prefs;
    }

    public AppTheme getCurrentTheme() {
        return AppTheme.fromIndex(prefs.getThemeIndex());
    }

    /** Terapkan warna aksen + opacity ke background lingkaran floating button. */
    public void applyToButtonBackground(GradientDrawable bg, int opacityPercent) {
        AppTheme theme = getCurrentTheme();
        int color = applyAlpha(theme.accentColor, opacityPercent);
        bg.setColor(color);
    }

    /** Terapkan warna background + opacity ke panel shortcut. */
    public void applyToPanelBackground(GradientDrawable bg, int opacityPercent) {
        AppTheme theme = getCurrentTheme();
        int color = applyAlpha(theme.backgroundColor, opacityPercent);
        bg.setColor(color);
    }

    public int getTextColor() {
        return getCurrentTheme().textColor;
    }

    public int getAccentColor() {
        return getCurrentTheme().accentColor;
    }

    private int applyAlpha(int colorArgb, int opacityPercent) {
        int alpha = (int) (255 * (opacityPercent / 100f));
        return Color.argb(alpha, Color.red(colorArgb), Color.green(colorArgb), Color.blue(colorArgb));
    }

    public static void setViewOpacity(View view, int opacityPercent) {
        view.setAlpha(opacityPercent / 100f);
    }
}
