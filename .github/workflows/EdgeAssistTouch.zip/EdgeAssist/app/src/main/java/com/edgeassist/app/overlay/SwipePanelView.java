package com.edgeassist.app.overlay;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.edgeassist.app.R;
import com.edgeassist.app.theme.ThemeManager;

/**
 * Panel carousel horizontal murni berbasis SWIPE GESTURE.
 * TIDAK ADA tombol next/previous/pagination - sesuai spesifikasi ketat.
 *
 * Implementasi: sebuah LinearLayout horizontal ("track") berisi N halaman,
 * masing-masing selebar panel. Saat drag, track ditranslasikan mengikuti jari.
 * Saat lepas, snap ke halaman terdekat menggunakan threshold 80dp, dengan
 * ValueAnimator untuk animasi halus (bisa dimatikan lewat setting animasi).
 */
public class SwipePanelView extends FrameLayout {

    public interface OnShortcutClickListener {
        void onShortcutClick(ShortcutItem item);
    }

    public interface OnOutsideDismissListener {
        void onRequestDismiss();
    }

    private static final int SWIPE_THRESHOLD_DP = 80;

    private final LinearLayout track;
    private final LinearLayout dotsRow;
    private int pageWidthPx;
    private int currentPage = 0;
    private int pageCount;
    private float downX;
    private float trackStartTranslation;
    private boolean isDragging = false;
    private boolean animationEnabled = true;

    private OnShortcutClickListener clickListener;
    private OnOutsideDismissListener dismissListener;

    private final GestureDetector tapDetector;

    public SwipePanelView(Context context, ShortcutItem[][] pages, ThemeManager themeManager,
                           int panelOpacityPercent, int iconSizePercent) {
        super(context);

        track = new LinearLayout(context);
        track.setOrientation(LinearLayout.HORIZONTAL);

        dotsRow = new LinearLayout(context);
        dotsRow.setOrientation(LinearLayout.HORIZONTAL);
        dotsRow.setGravity(android.view.Gravity.CENTER);

        setupPanelBackground(themeManager, panelOpacityPercent);
        buildPages(pages, themeManager, iconSizePercent);
        buildDots();

        addView(track);
        LayoutParams dotsParams = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        dotsParams.gravity = android.view.Gravity.BOTTOM | android.view.Gravity.CENTER_HORIZONTAL;
        dotsParams.bottomMargin = dp(6);
        addView(dotsRow, dotsParams);

        tapDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onSingleTapUp(MotionEvent e) {
                return handleTapOnChild(e);
            }
        });
    }

    private void setupPanelBackground(ThemeManager themeManager, int panelOpacityPercent) {
        GradientDrawable bg = (GradientDrawable) getResources()
                .getDrawable(R.drawable.panel_bg).mutate();
        themeManager.applyToPanelBackground(bg, panelOpacityPercent);
        setBackground(bg);
        setElevation(dp(6));
        setPadding(dp(8), dp(12), dp(8), dp(20));
    }

    private void buildPages(ShortcutItem[][] pages, ThemeManager themeManager, int iconSizePercent) {
        pageCount = pages.length;
        for (ShortcutItem[] page : pages) {
            LinearLayout pageLayout = new LinearLayout(getContext());
            pageLayout.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams pageParams = new LinearLayout.LayoutParams(dp(220), LinearLayout.LayoutParams.WRAP_CONTENT);
            pageLayout.setLayoutParams(pageParams);

            for (ShortcutItem item : page) {
                pageLayout.addView(buildItemView(item, themeManager, iconSizePercent));
            }
            track.addView(pageLayout);
        }
        pageWidthPx = dp(220);
    }

    private View buildItemView(final ShortcutItem item, ThemeManager themeManager, int iconSizePercent) {
        LinearLayout row = new LinearLayout(getContext());
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(10), dp(12), dp(10));
        row.setBackgroundResource(R.drawable.shortcut_item_bg);
        row.setTag(item);

        float emojiSize = 16 + (iconSizePercent / 100f) * 10f; // 16sp - 26sp

        TextView emojiView = new TextView(getContext());
        emojiView.setText(item.emoji);
        emojiView.setTextSize(TypedValue.COMPLEX_UNIT_SP, emojiSize);
        LinearLayout.LayoutParams emojiParams = new LinearLayout.LayoutParams(dp(36), LinearLayout.LayoutParams.WRAP_CONTENT);
        emojiView.setLayoutParams(emojiParams);
        emojiView.setGravity(android.view.Gravity.CENTER);

        TextView labelView = new TextView(getContext());
        labelView.setText(item.label);
        labelView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        labelView.setTextColor(themeManager.getTextColor());
        LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        labelParams.leftMargin = dp(8);
        labelView.setLayoutParams(labelParams);

        row.addView(emojiView);
        row.addView(labelView);
        return row;
    }

    private void buildDots() {
        for (int i = 0; i < pageCount; i++) {
            View dot = new View(getContext());
            LayoutParams p = new LayoutParams(dp(6), dp(6));
            p.leftMargin = dp(3);
            p.rightMargin = dp(3);
            dot.setLayoutParams(p);
            dot.setBackgroundResource(i == 0 ? R.drawable.dot_indicator_active : R.drawable.dot_indicator);
            dotsRow.addView(dot);
        }
    }

    private void refreshDots() {
        for (int i = 0; i < dotsRow.getChildCount(); i++) {
            dotsRow.getChildAt(i).setBackgroundResource(
                    i == currentPage ? R.drawable.dot_indicator_active : R.drawable.dot_indicator);
        }
    }

    public void setAnimationEnabled(boolean enabled) {
        this.animationEnabled = enabled;
    }

    public void setOnShortcutClickListener(OnShortcutClickListener listener) {
        this.clickListener = listener;
    }

    public void setOnOutsideDismissListener(OnOutsideDismissListener listener) {
        this.dismissListener = listener;
    }

    // ---- Gesture handling: SWIPE ONLY, no next/prev buttons ----

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        tapDetector.onTouchEvent(event);

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = event.getRawX();
                trackStartTranslation = track.getTranslationX();
                isDragging = false;
                return true;

            case MotionEvent.ACTION_MOVE: {
                float dx = event.getRawX() - downX;
                if (Math.abs(dx) > dp(8)) {
                    isDragging = true;
                }
                if (isDragging) {
                    float newTranslation = trackStartTranslation + dx;
                    // batasi agar tidak swipe melewati halaman pertama/terakhir terlalu jauh
                    float min = -(pageCount - 1) * pageWidthPx - dp(40);
                    float max = dp(40);
                    if (newTranslation < min) newTranslation = min;
                    if (newTranslation > max) newTranslation = max;
                    track.setTranslationX(newTranslation);
                }
                return true;
            }

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                if (isDragging) {
                    float dx = event.getRawX() - downX;
                    if (dx <= -dp(SWIPE_THRESHOLD_DP) && currentPage < pageCount - 1) {
                        currentPage++;
                    } else if (dx >= dp(SWIPE_THRESHOLD_DP) && currentPage > 0) {
                        currentPage--;
                    }
                    snapToCurrentPage();
                }
                isDragging = false;
                return true;
            }
        }
        return super.onTouchEvent(event);
    }

    private boolean handleTapOnChild(MotionEvent e) {
        if (isDragging) return false;
        // cari view anak yang ditap di halaman aktif
        LinearLayout activePage = (LinearLayout) track.getChildAt(currentPage);
        float localX = e.getX() - getPaddingLeft();
        float localY = e.getY() - getPaddingTop();
        for (int i = 0; i < activePage.getChildCount(); i++) {
            View child = activePage.getChildAt(i);
            if (localY >= child.getTop() && localY <= child.getBottom()
                    && localX >= 0 && localX <= child.getWidth()) {
                ShortcutItem item = (ShortcutItem) child.getTag();
                if (item != null && clickListener != null) {
                    clickListener.onShortcutClick(item);
                    return true;
                }
            }
        }
        // tap di luar item tapi di dalam panel -> tidak dismiss (biar tidak sensitif)
        return false;
    }

    private void snapToCurrentPage() {
        float target = -currentPage * pageWidthPx;
        refreshDots();
        if (animationEnabled) {
            ValueAnimator animator = ValueAnimator.ofFloat(track.getTranslationX(), target);
            animator.setDuration(220);
            animator.addUpdateListener(a -> track.setTranslationX((float) a.getAnimatedValue()));
            animator.start();
        } else {
            track.setTranslationX(target);
        }
    }

    private int dp(int value) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics());
    }
}
