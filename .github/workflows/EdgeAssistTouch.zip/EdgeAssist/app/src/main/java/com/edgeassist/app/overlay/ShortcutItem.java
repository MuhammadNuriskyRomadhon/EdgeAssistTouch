package com.edgeassist.app.overlay;

public class ShortcutItem {

    public enum Id {
        BACK, HOME, RECENTS, VOL_UP, VOL_DOWN,
        MUTE, LOCK, POWER, SCREENSHOT, NOTIFICATIONS,
        QUICK_SETTINGS, WIFI, FLASHLIGHT, MORE, SETTINGS
    }

    public final Id id;
    public final String emoji;
    public final String label;

    public ShortcutItem(Id id, String emoji, String label) {
        this.id = id;
        this.emoji = emoji;
        this.label = label;
    }

    /** Urutan 3 halaman x 5 item, PERSIS sesuai spesifikasi (tanpa tombol next/prev). */
    public static ShortcutItem[][] buildPages(android.content.Context ctx) {
        return new ShortcutItem[][]{
                {
                        new ShortcutItem(Id.BACK, "◀", ctx.getString(com.edgeassist.app.R.string.sc_back)),
                        new ShortcutItem(Id.HOME, "🏠", ctx.getString(com.edgeassist.app.R.string.sc_home)),
                        new ShortcutItem(Id.RECENTS, "▣", ctx.getString(com.edgeassist.app.R.string.sc_recents)),
                        new ShortcutItem(Id.VOL_UP, "🔊", ctx.getString(com.edgeassist.app.R.string.sc_vol_up)),
                        new ShortcutItem(Id.VOL_DOWN, "🔉", ctx.getString(com.edgeassist.app.R.string.sc_vol_down)),
                },
                {
                        new ShortcutItem(Id.MUTE, "🔇", ctx.getString(com.edgeassist.app.R.string.sc_mute)),
                        new ShortcutItem(Id.LOCK, "🔒", ctx.getString(com.edgeassist.app.R.string.sc_lock)),
                        new ShortcutItem(Id.POWER, "⏻", ctx.getString(com.edgeassist.app.R.string.sc_power)),
                        new ShortcutItem(Id.SCREENSHOT, "📸", ctx.getString(com.edgeassist.app.R.string.sc_screenshot)),
                        new ShortcutItem(Id.NOTIFICATIONS, "🔔", ctx.getString(com.edgeassist.app.R.string.sc_notifications)),
                },
                {
                        new ShortcutItem(Id.QUICK_SETTINGS, "⚙", ctx.getString(com.edgeassist.app.R.string.sc_quick_settings)),
                        new ShortcutItem(Id.WIFI, "📶", ctx.getString(com.edgeassist.app.R.string.sc_wifi)),
                        new ShortcutItem(Id.FLASHLIGHT, "🔦", ctx.getString(com.edgeassist.app.R.string.sc_flashlight)),
                        new ShortcutItem(Id.MORE, "☰", ctx.getString(com.edgeassist.app.R.string.sc_more)),
                        new ShortcutItem(Id.SETTINGS, "⚙", ctx.getString(com.edgeassist.app.R.string.sc_settings)),
                }
        };
    }
}
