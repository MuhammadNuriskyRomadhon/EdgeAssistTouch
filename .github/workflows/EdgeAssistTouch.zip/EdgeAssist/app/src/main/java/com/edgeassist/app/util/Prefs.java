package com.edgeassist.app.util;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Wrapper tunggal untuk semua penyimpanan setting.
 * Tidak memakai database - hanya SharedPreferences sesuai spesifikasi (ringan, cepat).
 */
public class Prefs {

    private static final String PREF_NAME = "edgeassist_prefs";

    // Keys
    public static final String KEY_FIRST_RUN_DONE = "first_run_done";
    public static final String KEY_BUTTON_X = "button_x";
    public static final String KEY_BUTTON_Y = "button_y";
    public static final String KEY_BUTTON_SIZE = "button_size"; // 0-100 -> mapped to dp
    public static final String KEY_BUTTON_OPACITY = "button_opacity"; // 0-100
    public static final String KEY_PANEL_OPACITY = "panel_opacity"; // 0-100
    public static final String KEY_ICON_SIZE = "icon_size"; // 0-100
    public static final String KEY_AUTO_HIDE = "auto_hide";
    public static final String KEY_AUTO_HIDE_DELAY = "auto_hide_delay"; // seconds
    public static final String KEY_ANIMATION = "animation_enabled";
    public static final String KEY_THEME = "theme_index";
    public static final String KEY_SIDE = "side"; // 0 = left, 1 = right
    public static final String KEY_DEVICE_ADMIN_PROMPTED = "device_admin_prompted";

    private final SharedPreferences sp;

    public Prefs(Context context) {
        sp = context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public boolean isFirstRunDone() {
        return sp.getBoolean(KEY_FIRST_RUN_DONE, false);
    }

    public void setFirstRunDone(boolean done) {
        sp.edit().putBoolean(KEY_FIRST_RUN_DONE, done).apply();
    }

    public int getButtonX(int defaultVal) {
        return sp.getInt(KEY_BUTTON_X, defaultVal);
    }

    public int getButtonY(int defaultVal) {
        return sp.getInt(KEY_BUTTON_Y, defaultVal);
    }

    public void setButtonPosition(int x, int y) {
        sp.edit().putInt(KEY_BUTTON_X, x).putInt(KEY_BUTTON_Y, y).apply();
    }

    public int getButtonSize() {
        return sp.getInt(KEY_BUTTON_SIZE, 50); // default mid
    }

    public void setButtonSize(int val) {
        sp.edit().putInt(KEY_BUTTON_SIZE, val).apply();
    }

    public int getButtonOpacity() {
        return sp.getInt(KEY_BUTTON_OPACITY, 85);
    }

    public void setButtonOpacity(int val) {
        sp.edit().putInt(KEY_BUTTON_OPACITY, val).apply();
    }

    public int getPanelOpacity() {
        return sp.getInt(KEY_PANEL_OPACITY, 95);
    }

    public void setPanelOpacity(int val) {
        sp.edit().putInt(KEY_PANEL_OPACITY, val).apply();
    }

    public int getIconSize() {
        return sp.getInt(KEY_ICON_SIZE, 50);
    }

    public void setIconSize(int val) {
        sp.edit().putInt(KEY_ICON_SIZE, val).apply();
    }

    public boolean isAutoHideEnabled() {
        return sp.getBoolean(KEY_AUTO_HIDE, false);
    }

    public void setAutoHideEnabled(boolean val) {
        sp.edit().putBoolean(KEY_AUTO_HIDE, val).apply();
    }

    public int getAutoHideDelaySeconds() {
        return sp.getInt(KEY_AUTO_HIDE_DELAY, 3);
    }

    public void setAutoHideDelaySeconds(int val) {
        sp.edit().putInt(KEY_AUTO_HIDE_DELAY, val).apply();
    }

    public boolean isAnimationEnabled() {
        return sp.getBoolean(KEY_ANIMATION, true);
    }

    public void setAnimationEnabled(boolean val) {
        sp.edit().putBoolean(KEY_ANIMATION, val).apply();
    }

    public int getThemeIndex() {
        return sp.getInt(KEY_THEME, 0); // 0 = Dark default
    }

    public void setThemeIndex(int index) {
        sp.edit().putInt(KEY_THEME, index).apply();
    }

    public int getSide() {
        return sp.getInt(KEY_SIDE, 1); // default kanan
    }

    public void setSide(int side) {
        sp.edit().putInt(KEY_SIDE, side).apply();
    }

    public boolean wasDeviceAdminPrompted() {
        return sp.getBoolean(KEY_DEVICE_ADMIN_PROMPTED, false);
    }

    public void setDeviceAdminPrompted(boolean val) {
        sp.edit().putBoolean(KEY_DEVICE_ADMIN_PROMPTED, val).apply();
    }

    public void resetAll() {
        boolean firstRun = isFirstRunDone();
        sp.edit().clear().apply();
        setFirstRunDone(firstRun);
    }
}
