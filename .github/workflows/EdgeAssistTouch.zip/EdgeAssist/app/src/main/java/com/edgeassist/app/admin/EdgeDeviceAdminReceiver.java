package com.edgeassist.app.admin;

import android.app.admin.DeviceAdminReceiver;

/**
 * Device Admin receiver MINIMAL - hanya policy force-lock (lihat device_admin_receiver.xml).
 * Tidak mengimplementasikan wipe data, password policy, atau kontrol lain.
 * Satu-satunya tujuan: memungkinkan DevicePolicyManager.lockNow() bekerja di API 27,
 * karena GLOBAL_ACTION_LOCK_SCREEN baru tersedia mulai API 28.
 */
public class EdgeDeviceAdminReceiver extends DeviceAdminReceiver {
    // Tidak perlu override apa pun - perilaku default sudah cukup.
}
