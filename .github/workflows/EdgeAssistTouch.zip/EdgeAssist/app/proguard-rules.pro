# EdgeAssist - aturan proguard minimal
-keep class com.edgeassist.app.service.** { *; }
-keep class com.edgeassist.app.admin.** { *; }
