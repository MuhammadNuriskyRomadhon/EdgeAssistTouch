# EdgeAssist

Assistive floating button (mirip AssistiveTouch iPhone) untuk menggantikan tombol
fisik yang rusak. Dibuat khusus untuk **Infinix HOT S3X (X622) — Android 8.1 / API 27,
RAM 3 GB**, tapi berjalan di device Android 8.1+ manapun.

100% offline. Tidak ada permission INTERNET. Tidak ada analytics/ads/tracker.

---

## ⚠️ Catatan penting tentang APK

Saya (Claude) membuat **seluruh source code project ini agar bisa langsung dibuka
dan di-build di Android Studio**. Namun sandbox tempat saya menjalankan kode
**tidak punya akses ke Android SDK maupun Google Maven repository**
(`dl.google.com` diblokir oleh jaringan sandbox), sehingga saya **tidak bisa
mengompilasi APK di sini**. Anda perlu build sendiri di Android Studio — langkahnya
di bawah, dan biasanya hanya butuh beberapa menit.

---

## 1. Cara membuka project di Android Studio

1. Download/salin seluruh folder `EdgeAssist/` ini ke komputer Anda.
2. Buka **Android Studio** → `File` → `Open` → pilih folder `EdgeAssist`.
3. Tunggu proses **Gradle Sync** selesai (Android Studio otomatis download
   Android Gradle Plugin & dependency AndroidX yang dibutuhkan — pastikan
   komputer Anda terkoneksi internet saat langkah ini).
4. Jika diminta update Gradle/AGP oleh Android Studio, **boleh diterima** —
   project ini ditulis dengan AGP 4.1.3 yang kompatibel luas, tapi versi
   yang lebih baru juga akan tetap bisa build project ini.

## 2. Cara build APK

**Lewat Android Studio (termudah):**
- `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`.
- APK hasil build ada di `app/build/outputs/apk/debug/app-debug.apk`.

**Lewat terminal (opsional):**
```bash
cd EdgeAssist
./gradlew assembleDebug
```
(Jika `gradlew` tidak executable: `chmod +x gradlew` dulu di Mac/Linux.)

## 3. Cara install APK ke HP

1. Salin `app-debug.apk` ke HP Infinix HOT S3X Anda (lewat kabel USB, atau
   share file).
2. Di HP, buka file APK tersebut lewat File Manager.
3. Jika muncul peringatan "Install dari sumber tidak dikenal", izinkan
   (Settings → Security → Unknown sources, khusus untuk XOS/Android 8.1).
4. Install seperti biasa.

---

## 🔥 Cara build APK TANPA PC/laptop (pakai GitHub Actions, cukup dari HP)

Kalau Anda tidak punya PC, ikuti langkah ini — semua bisa dilakukan lewat browser
di HP (Chrome/dll). Yang "build" APK adalah server GitHub, bukan HP Anda.

**Langkah 1 — Buat akun GitHub (gratis)**
Buka https://github.com/signup lewat browser HP, daftar pakai email.

**Langkah 2 — Buat repository baru**
1. Tap tombol `+` di pojok kanan atas → `New repository`.
2. Nama repo: `EdgeAssist` (atau bebas).
3. Set ke **Public** atau **Private** (bebas), lalu `Create repository`.

**Langkah 3 — Upload semua file project**
1. Extract dulu `EdgeAssist.zip` di HP (pakai app File Manager / ZArchiver / dll
   yang support extract folder).
2. Di halaman repo GitHub yang baru dibuat, tap `Add file` → `Upload files`.
3. Dari file manager HP, **select semua isi folder `EdgeAssist`** (termasuk folder
   tersembunyi `.github`) lalu upload. Kalau browser HP tidak bisa upload folder
   sekaligus, upload per-folder satu-satu (`app`, `.github`, lalu file-file di root
   seperti `build.gradle`, `settings.gradle`, `gradle.properties`).
4. Scroll ke bawah, tap `Commit changes`.

**Langkah 4 — Build otomatis jalan sendiri**
1. Tap tab `Actions` di bagian atas repo.
2. Akan muncul workflow **"Build EdgeAssist APK"** sedang berjalan (ikon kuning
   berputar). Tunggu 3-5 menit sampai jadi ✅ centang hijau.
   (Kalau tidak otomatis jalan, tap `Run workflow` manual.)

**Langkah 5 — Download APK hasil build**
1. Tap workflow run yang sudah selesai (centang hijau).
2. Scroll ke bawah ke bagian `Artifacts`.
3. Tap **`EdgeAssist-debug-apk`** untuk download (dalam bentuk zip berisi APK).
4. Extract, dapatkan `app-debug.apk`.
5. Buka file itu di HP → Install (izinkan "unknown sources" kalau diminta).

Selesai — APK siap install, semua dilakukan dari HP tanpa PC/laptop sama sekali.

---

## 4. Cara mengaktifkan Accessibility Service

Saat pertama kali membuka EdgeAssist, wizard akan memandu Anda. Jika perlu manual:

`Settings` → `Accessibility` → cari **EdgeAssist** → aktifkan toggle.

Tanpa ini, tombol Back / Home / Recent Apps / Notifications / Quick Settings /
Power Menu **tidak akan berfungsi** (akan muncul pesan
*"Silakan aktifkan EdgeAssist Accessibility Service"*).

## 5. Cara mengaktifkan izin Overlay

`Settings` → `Apps` → `EdgeAssist` → `Display over other apps` → aktifkan.

Tanpa ini, tombol floating tidak akan muncul sama sekali.

## 6. (Opsional) Device Admin untuk Lock Screen

Karena Android 8.1 (API 27) **belum punya** `GLOBAL_ACTION_LOCK_SCREEN` (baru
tersedia di API 28+), shortcut **Lock Screen** memakai `DevicePolicyManager.lockNow()`
yang membutuhkan **Device Admin**. Saat pertama membuka Settings, aplikasi akan
menawarkan aktivasi ini sekali. Anda boleh menolak — hanya shortcut Lock Screen
saja yang tidak akan berfungsi, fitur lain tetap normal.

---

## Keterbatasan Android 8.1 / API 27 (jujur, tanpa klaim palsu)

| Fitur | Status di API 27 |
|---|---|
| Back, Home, Recent Apps | ✅ Native via AccessibilityService |
| Notifications, Quick Settings, Power Menu | ✅ Native via AccessibilityService |
| Volume +/−, Mute | ✅ Native via AudioManager |
| Flashlight | ✅ Native via `CameraManager.setTorchMode()` — **tanpa permission CAMERA** |
| Wi-Fi toggle | ⚠️ `WifiManager.setWifiEnabled()` (masih berfungsi di API 27, dibatasi mulai Android 10+); fallback membuka Settings jika ditolak sistem/OEM |
| Lock Screen | ⚠️ Perlu **Device Admin** (`lockNow()`), karena global action lock baru ada di API 28+ |
| Screenshot | ❌ **Tidak tersedia** secara resmi tanpa root di API 27. Shortcut tetap tampil tapi menampilkan pesan "tidak tersedia" — **tidak memakai exploit/hack apa pun** |

---

## Struktur Project

```
app/src/main/java/com/edgeassist/app/
 ├── MainActivity.java              # Setup wizard 4 langkah
 ├── SettingsActivity.java          # Semua kustomisasi (tema, ukuran, opacity, dst)
 ├── PrivacyActivity.java           # Halaman privacy/about
 ├── service/
 │    ├── EdgeAccessibilityService.java   # Global actions (Back/Home/dst), TIDAK baca layar
 │    ├── FloatingOverlayService.java     # Floating button draggable + panel
 │    └── ServiceHolder.java              # Jembatan antar service
 ├── overlay/
 │    ├── ShortcutItem.java         # Data 15 shortcut (3 halaman x 5)
 │    └── SwipePanelView.java       # Carousel SWIPE-ONLY, tanpa tombol next/prev
 ├── actions/
 │    ├── ShortcutActions.java      # Eksekusi setiap shortcut + fallback graceful
 │    ├── FlashlightController.java
 │    └── ActionResult.java
 ├── theme/
 │    ├── AppTheme.java             # 8 tema (Dark/Light/Midnight/Ocean/Purple/Red/Green/Minimal)
 │    └── ThemeManager.java
 ├── admin/
 │    └── EdgeDeviceAdminReceiver.java   # Minimal, hanya force-lock policy
 └── util/
      └── Prefs.java                # SharedPreferences (tanpa database)
```

## Prinsip yang dijaga di seluruh kode

- **Tanpa root, exploit, hidden API, atau reflection ke API privat.**
- **Tanpa INTERNET permission** — tidak ada baris kode yang membuka koneksi jaringan.
- **Tanpa polling/loop berkala** — satu-satunya `Handler.postDelayed` dipakai untuk
  auto-hide (single-shot, dibatalkan saat disentuh), bukan polling.
- **Tanpa Firebase/Analytics/Ads SDK** — dependency hanya `androidx.appcompat` &
  `androidx.core` untuk UI dasar.
- Setiap pengecekan versi API memakai `Build.VERSION.SDK_INT` sebelum memanggil API
  yang mungkin tidak tersedia (walaupun karena `minSdkVersion = targetSdkVersion = 27`,
  hampir semua API yang dipakai memang tersedia sejak API 27 ke bawah).
- Navigasi shortcut **100% swipe gesture**, tidak ada tombol `<` `>` / Next / Previous.

## Known limitation dari implementasi ini

- Belum diuji langsung di perangkat fisik (tidak bisa build APK di sandbox ini) —
  disarankan uji coba di Infinix HOT S3X asli setelah build, dan laporkan jika ada
  penyesuaian XOS 4.0 yang perlu (misal beberapa OEM membatasi overlay/battery
  optimization secara agresif — tambahkan EdgeAssist ke whitelist battery saver
  jika service sering mati sendiri).
- Ikon aplikasi dibuat sederhana secara programatik (lingkaran biru) — silakan
  ganti `mipmap-*/ic_launcher.png` dengan desain Anda sendiri jika mau.
